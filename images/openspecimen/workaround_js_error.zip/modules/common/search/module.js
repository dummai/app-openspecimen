
angular.module('os.common.search',
  [
    'os.common.search.service',
    'os.common.search.ctrl'
  ]);
