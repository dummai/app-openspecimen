
angular.module('os.common', ['ui.router', 'os.common.models', 'os.common.form', 'os.common.delete', 'os.common.search']);
