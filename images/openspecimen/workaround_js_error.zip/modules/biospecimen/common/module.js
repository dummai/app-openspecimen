
angular.module('os.biospecimen.common', 
  [
    'os.biospecimen.common.specimenqtyvalidate',
    'os.biospecimen.common.uniquespecimenlabel',
    'os.biospecimen.common.specimenprops',
    'os.biospecimen.common.specimendesc',
    'os.biospecimen.common.eventdesc'
  ]
);
