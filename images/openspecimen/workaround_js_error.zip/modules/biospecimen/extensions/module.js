
angular.module('os.biospecimen.extensions', 
  [
    'os.biospecimen.extensions.list',
    'os.biospecimen.extensions.addedit-record',
    'os.biospecimen.extensions.util'
  ]
);
