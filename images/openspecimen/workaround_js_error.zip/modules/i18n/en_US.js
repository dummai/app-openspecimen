{
  "participant": {
    "id": "MPI / MRN / SSN",
    "uid": "Social Security Number",
    "uid_short": "SSN",

    "matching_attr": {
      "uid": "SSN"
    }
  }
}