{
  "participant": {
    "id": "MPI / MRN / MEDICARE",
    "uid": "Medicare Number",
    "uid_short": "MEDICARE",

    "matching_attr": {
      "uid": "MEDICARE"
    }
  }
}
