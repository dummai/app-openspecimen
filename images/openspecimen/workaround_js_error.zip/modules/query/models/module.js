
angular.module('os.query.models', 
  [
    'os.query.models.savedquery',
    'os.query.models.queryfolder'
  ]
);
