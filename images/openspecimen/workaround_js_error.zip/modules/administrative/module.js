
angular.module('os.administrative',
  [
    'os.administrative.models',
    'os.administrative.user',
    'os.administrative.institute',
    'os.administrative.site',
    'os.administrative.dp',
    'os.administrative.order',
    'os.administrative.shipment',
    'os.administrative.container',
    'os.administrative.containertype',
    'os.administrative.role',
    'os.administrative.form',
    'os.administrative.job',
    'os.administrative.setting'
  ]
);
