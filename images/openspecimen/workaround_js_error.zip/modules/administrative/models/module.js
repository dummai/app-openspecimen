
angular.module('os.administrative.models', 
  [
    'os.administrative.models.user',
    'os.administrative.models.institute',
    'os.administrative.models.site',
    'os.administrative.models.dp',
    'os.administrative.models.order',
    'os.administrative.models.dpr',
    'os.administrative.models.shipment',
    'os.administrative.models.container',
    'os.administrative.models.containertype',
    'os.administrative.models.role',
    'os.administrative.models.setting',
    'os.administrative.models.authdomain',
    'os.administrative.models.job',
    'os.administrative.models.support'
  ]
);
 
